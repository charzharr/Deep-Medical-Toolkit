""" dmt/data/loading/mtm_loader.py
Multi-sample to multi-example multiprocessed loader. 
Multi-sample means that it requires multiple (>=1) dataset samples to create
multiple (>=1) batch examples. It is a generalized form of OTO & OTM loaders.

TODO: when project demands it, implement & add to data __init__ file.
"""

class ManyToManyLoader:
    pass